// =====================================================
// Carga el contenido editable (JSON) y lo inserta en el HTML.
// =====================================================

function waLink(numero, mensaje) {
  const num = (numero || '').replace(/\D/g, '');
  return `https://wa.me/${num}?text=${encodeURIComponent(mensaje)}`;
}

async function cargarContenido() {
  try {
    const [sitio, sedesData, programasData, galeriaData] = await Promise.all([
      fetch('/content/sitio.json').then(r => r.json()),
      fetch('/content/sedes.json').then(r => r.json()),
      fetch('/content/programas.json').then(r => r.json()),
      fetch('/content/galeria.json').then(r => r.json())
    ]);

    // ---- Hero ----
    document.querySelectorAll('[data-campo="hero_titulo"]').forEach(el => el.textContent = sitio.hero_titulo);
    document.querySelectorAll('[data-campo="hero_subtitulo"]').forEach(el => el.textContent = sitio.hero_subtitulo);
    const heroImg = document.getElementById('hero-imagen');
    if (heroImg && sitio.hero_imagen) heroImg.src = sitio.hero_imagen;

    // ---- Nuestra diferencia ----
    document.querySelectorAll('[data-campo="diferencia_frase"]').forEach(el => el.textContent = sitio.diferencia_frase);
    document.querySelectorAll('[data-campo="diferencia_valores"]').forEach(el => el.textContent = sitio.diferencia_valores);
    const diferenciaImg = document.getElementById('diferencia-imagen');
    if (diferenciaImg && sitio.diferencia_imagen) diferenciaImg.src = sitio.diferencia_imagen;

    // ---- WhatsApp general (hero, flotante, formulario) ----
    const numeroGeneral = sitio.whatsapp_general;
    const heroWaBtn = document.getElementById('hero-wa-btn');
    if (heroWaBtn) heroWaBtn.href = waLink(numeroGeneral, 'Hola, necesito información sobre Danny Man Academy');
    const flotanteBtn = document.getElementById('wa-flotante-boton');
    if (flotanteBtn) flotanteBtn.href = waLink(numeroGeneral, 'Hola, necesito información sobre Danny Man Academy');
    window._whatsappGeneral = numeroGeneral;
    document.querySelectorAll('[data-campo="instagram_url"]').forEach(el => el.href = sitio.instagram_url);
    document.querySelectorAll('[data-campo="facebook_url"]').forEach(el => el.href = sitio.facebook_url);

    // ---- Galería ----
    const galeriaContenedor = document.getElementById('galeria-contenedor');
    if (galeriaContenedor) {
      galeriaContenedor.innerHTML = (galeriaData.fotos || []).map(f => `
        <a href="${f.imagen}" target="_blank" rel="noopener"><img src="${f.imagen}" alt="${f.descripcion || ''}" loading="lazy"></a>
      `).join('');
    }

    // ---- Sedes ----
    const sedes = sedesData.sedes;
    const sedesContenedor = document.getElementById('sedes-contenedor');
    if (sedesContenedor) {
      sedesContenedor.innerHTML = sedes.map(sede => `
        <div class="sede-card">
          <img src="${sede.foto}" alt="${sede.nombre}" loading="lazy">
          <div class="sede-body">
            <span class="eyebrow">Sede</span>
            <h3>${sede.nombre}</h3>
            <p>${sede.direccion}</p>
            <div class="sede-btns">
              <a href="${sede.maps_url}" target="_blank" rel="noopener" class="btn btn-outline-dark">Cómo llegar</a>
              <a href="${waLink(sede.whatsapp_numero, 'Hola, quiero información sobre la sede ' + sede.nombre)}" data-whatsapp data-origen="sede-${sede.nombre}" class="btn btn-wa">WhatsApp</a>
            </div>
          </div>
        </div>
      `).join('');
    }

    // Llena el <select> de sedes en el formulario
    const selectSede = document.getElementById('sede');
    if (selectSede) {
      selectSede.innerHTML = sedes.map(s => `<option value="${s.nombre}">${s.nombre}</option>`).join('');
    }

    // Pie de página: lista de sedes
    const footerSedes = document.getElementById('footer-sedes');
    if (footerSedes) {
      footerSedes.innerHTML = sedes.map(s => `<span>${s.nombre}</span>`).join('<span>|</span>');
    }

    // ---- Programas (acordeón) ----
    const programas = programasData.programas;
    const programasContenedor = document.getElementById('programas-contenedor');
    if (programasContenedor) {
      programasContenedor.innerHTML = programas.map((p, i) => `
        <div class="prog-card" data-index="${i}">
          <button class="prog-toggle" aria-expanded="false">
            <img src="${p.foto}" alt="${p.nombre}" loading="lazy">
            <div class="prog-hover-msg"><span>Presiona para ver más información</span></div>
            <div class="prog-overlay">
              <span class="prog-tag">${p.etiqueta}</span>
              <h3>${p.nombre}</h3>
              <p>${p.descripcion_corta}</p>
            </div>
          </button>
          <div class="prog-detalle">
            <p>${p.descripcion_larga}</p>
            <a href="#demo" class="btn btn-rojo">Pedir información</a>
          </div>
        </div>
      `).join('');

      programasContenedor.querySelectorAll('.prog-toggle').forEach(btn => {
        btn.addEventListener('click', () => {
          const card = btn.closest('.prog-card');
          const abierta = card.classList.contains('abierta');
          programasContenedor.querySelectorAll('.prog-card').forEach(c => {
            c.classList.remove('abierta');
            c.querySelector('.prog-toggle').setAttribute('aria-expanded', 'false');
          });
          if (!abierta) {
            card.classList.add('abierta');
            btn.setAttribute('aria-expanded', 'true');
          }
        });
      });
    }

  } catch (error) {
    console.error('Error cargando el contenido:', error);
  }
}

document.addEventListener('DOMContentLoaded', cargarContenido);

// Formulario de clase demo -> arma el mensaje y abre WhatsApp del número general
document.addEventListener('DOMContentLoaded', () => {
  const form = document.getElementById('demoForm');
  if (!form) return;
  form.addEventListener('submit', function (e) {
    e.preventDefault();
    const representante = document.getElementById('representante').value;
    const alumno = document.getElementById('alumno').value;
    const edad = document.getElementById('edad').value;
    const telefono = document.getElementById('telefono').value;
    const sedeNombre = document.getElementById('sede').value;
    const programa = document.getElementById('programa').value;
    const horario = document.getElementById('horario').value;

    const mensaje = `Hola, quiero agendar una clase demostrativa gratuita.
Representante: ${representante}
Alumno: ${alumno}
Edad: ${edad}
Teléfono: ${telefono}
Sede: ${sedeNombre}
Programa de interés: ${programa}
Horario preferido: ${horario}`;

    trackLead(sedeNombre, programa);
    window.open(waLink(window._whatsappGeneral, mensaje), '_blank');
  });
});
